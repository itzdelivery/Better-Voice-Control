#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/ui/Popup.hpp>
#include <Geode/ui/ScrollLayer.hpp>
#include <atomic>
#include <vector>
#include <string>

#define MINIAUDIO_IMPLEMENTATION
#include "miniaudio.h"

using namespace geode::prelude;

struct AudioSettings {
    std::atomic<bool> enabled{true};
    std::atomic<float> currentVolume{0.0f};
    ma_device_id selectedDeviceId;
    bool hasSelectedDevice = false;
    float jumpThreshold = 0.02f; // Немного снизил для чувствительности
    float brrrThreshold = 0.12f; // Порог для спама
};

AudioSettings& getSettings() {
    static AudioSettings settings;
    return settings;
}

ma_device g_audioDevice;
bool g_isDeviceActive = false;

void data_callback(ma_device* pDevice, void* pOutput, const void* pInput, ma_uint32 frameCount) {
    if (pInput == nullptr || !getSettings().enabled) {
        getSettings().currentVolume = 0.0f;
        return;
    }
    const float* inputData = (const float*)pInput;
    float sumSquares = 0.0f;
    for (ma_uint32 i = 0; i < frameCount; ++i) {
        sumSquares += inputData[i] * inputData[i];
    }
    getSettings().currentVolume = std::sqrt(sumSquares / frameCount);
}

void stopAudio() {
    if (g_isDeviceActive) {
        ma_device_uninit(&g_audioDevice);
        g_isDeviceActive = false;
    }
}

void startAudio(ma_device_id* specificID = nullptr) {
    stopAudio();
    ma_device_config config = ma_device_config_init(ma_device_type_capture);
    config.capture.format = ma_format_f32;
    config.capture.channels = 1;
    config.sampleRate = 44100;
    config.dataCallback = data_callback;
    if (specificID) config.capture.pDeviceID = specificID;

    if (ma_device_init(NULL, &config, &g_audioDevice) == MA_SUCCESS) {
        if (ma_device_start(&g_audioDevice) == MA_SUCCESS) {
            g_isDeviceActive = true;
        }
    }
}

// Попап настроек
class MicSelectionPopup : public geode::Popup {
    struct MicInfo {
        ma_device_id id;
        std::string name;
    };
    std::vector<MicInfo> m_mics;

public:
    bool init(float width, float height) {
        if (!geode::Popup::init(width, height)) return false;
        this->setTitle("Voice Settings");
        auto winSize = m_mainLayer->getContentSize();

        auto menu = CCMenu::create();
        menu->setPosition({winSize.width / 2, winSize.height - 45.f});
        
        auto toggleLabel = CCLabelBMFont::create("Mod Active:", "bigFont.fnt");
        toggleLabel->setScale(0.4f);
        toggleLabel->setPosition({-40.f, 0.f});
        
        auto toggle = CCMenuItemToggler::create(
            CCSprite::createWithSpriteFrameName("GJ_checkOff_001.png"),
            CCSprite::createWithSpriteFrameName("GJ_checkOn_001.png"),
            this, menu_selector(MicSelectionPopup::onToggleMod)
        );
        toggle->toggle(getSettings().enabled);
        toggle->setPosition({40.f, 0.f});

        menu->addChild(toggleLabel);
        menu->addChild(toggle);
        m_mainLayer->addChild(menu);

        auto scroll = ScrollLayer::create({220.f, 100.f});
        scroll->setPosition({winSize.width / 2 - 110.f, 30.f});
        auto content = CCMenu::create();
        float sHeight = 0.f;

        ma_context context;
        if (ma_context_init(NULL, 0, NULL, &context) == MA_SUCCESS) {
            ma_device_info* pCaptureInfos;
            ma_uint32 captureCount;
            ma_context_get_devices(&context, NULL, NULL, &pCaptureInfos, &captureCount);
            for (ma_uint32 i = 0; i < captureCount; ++i) {
                auto name = std::string(pCaptureInfos[i].name);
                m_mics.push_back({pCaptureInfos[i].id, name});
                auto btnSpr = ButtonSprite::create(name.c_str(), 160, true, "goldFont.fnt", "GJ_button_05.png", 25.f, 0.4f);
                auto btn = CCMenuItemSpriteExtra::create(btnSpr, this, menu_selector(MicSelectionPopup::onSelectMic));
                btn->setTag(i);
                btn->setPosition({110.f, -sHeight - 20.f});
                content->addChild(btn);
                sHeight += 35.f;
            }
            ma_context_uninit(&context);
        }
        content->setContentSize({220.f, sHeight});
        content->setPosition({0.f, 0.f});
        scroll->m_contentLayer->addChild(content);
        scroll->m_contentLayer->setContentSize({220.f, sHeight});
        m_mainLayer->addChild(scroll);
        return true;
    }

    void onToggleMod(CCObject*) { getSettings().enabled = !getSettings().enabled; }
    void onSelectMic(CCObject* sender) {
        int idx = sender->getTag();
        if (idx < (int)m_mics.size()) {
            getSettings().selectedDeviceId = m_mics[idx].id;
            getSettings().hasSelectedDevice = true;
            startAudio(&getSettings().selectedDeviceId);
            FLAlertLayer::create("Audio", "Mic Switched!", "OK")->show();
        }
    }

    static MicSelectionPopup* create() {
        auto ret = new MicSelectionPopup();
        if (ret && ret->init(280.f, 220.f)) {
            ret->autorelease();
            return ret;
        }
        CC_SAFE_DELETE(ret);
        return nullptr;
    }
};

class $modify(MyPlayLayer, PlayLayer) {
    struct Fields {
        bool m_isHolding = false;
        int m_spamCounter = 0;
    };

    void postUpdate(float dt) {
        PlayLayer::postUpdate(dt);
        if (!getSettings().enabled || m_player1->m_isDead) return;

        float vol = getSettings().currentVolume.load();
        auto player = m_player1;

        // ЛОГИКА "БРРР" (ОЧЕНЬ ГРОМКО) -> СПАМ
        if (vol >= getSettings().brrrThreshold) {
            m_fields->m_spamCounter++;
            // Спамим каждые 3 кадра для стабильности (на 144гц/240гц это лучше всего)
            if (m_fields->m_spamCounter % 3 == 0) {
                player->pushButton(PlayerButton::Jump);
            } else {
                player->releaseButton(PlayerButton::Jump);
            }
            m_fields->m_isHolding = true; 
        } 
        // ЛОГИКА "ЗАЖАТИЕ" (ГРОМКО) -> ПРЫЖОК
        else if (vol >= getSettings().jumpThreshold) {
            if (!m_fields->m_isHolding) {
                player->pushButton(PlayerButton::Jump);
                m_fields->m_isHolding = true;
            }
            // Если мы просто зажимаем, счетчик спама не нужен
            m_fields->m_spamCounter = 0;
        } 
        // ТИШИНА -> ОТПУСКАЕМ
        else {
            if (m_fields->m_isHolding) {
                player->releaseButton(PlayerButton::Jump);
                m_fields->m_isHolding = false;
                m_fields->m_spamCounter = 0;
            }
        }
    }
};

class $modify(MyMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;
        auto spr = ButtonSprite::create("Voice", "goldFont.fnt", "GJ_button_01.png", 0.6f);
        auto btn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(MyMenuLayer::onVoiceSettings));
        if (auto menu = this->getChildByID("bottom-menu")) {
            menu->addChild(btn);
            menu->updateLayout();
        }
        return true;
    }
    void onVoiceSettings(CCObject*) { MicSelectionPopup::create()->show(); }
};

$on_mod(Loaded) { startAudio(); }