if ya scream, you get high!
so its my first mod, join discord btw :DD